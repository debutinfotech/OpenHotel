//
//  ViewController.m
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import "ViewController.h"
#import "LoginVC.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBarHidden = TRUE;
    
    splashProgressView.progress = 0.0;
    [self performSelectorOnMainThread:@selector(makeMyProgressBarMoving) withObject:nil waitUntilDone:NO];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
}

- (void)makeMyProgressBarMoving
{
    float actual = [splashProgressView progress];
    
    if (actual < 1)
    {
        actual = actual + 0.008;
        splashProgressView.progress = actual;
        [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(makeMyProgressBarMoving) userInfo:nil repeats:NO];
    }
    else
    {
        [self performSelector:@selector(callLogin) withObject:self afterDelay:0.4];
    }
}

- (void) callLogin
{
    LoginVC *obj;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        if ([[UIScreen mainScreen] bounds].size.height > 480.0f)
        {
            obj = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil];
        }
        else
        {
            obj = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil];
        }
    }
    else
    {
        if (UIDeviceOrientationIsLandscape(self.interfaceOrientation))
        {
            obj = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil];
        }
        if (UIDeviceOrientationIsPortrait(self.interfaceOrientation))
        {
            obj = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil];
        }
    }
    
    [self.navigationController pushViewController:obj animated:YES];
}

- (IBAction)customCameraBtnTapped:(id)sender
{

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
