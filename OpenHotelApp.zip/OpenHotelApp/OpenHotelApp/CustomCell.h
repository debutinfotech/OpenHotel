//
//  CustomCell.h
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//Delegate Starts
@protocol customCellDelegate<NSObject>

-(void)checkInButtonDelegateMethodPressed:(UITableViewCell*)cell;

@end


@interface CustomCell : UITableViewCell

@property(unsafe_unretained) id<customCellDelegate>delegate;
@property (strong, nonatomic) IBOutlet UILabel *guestNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *mobileLbl;
@property (strong, nonatomic) IBOutlet UILabel *dateLbl;
@property (strong, nonatomic) IBOutlet UIImageView *circleIV;
@property(strong,nonatomic) IBOutlet UIButton *checkinButtonPressed;
-(IBAction)checkInButtonPressed:(id)sender;

@end
