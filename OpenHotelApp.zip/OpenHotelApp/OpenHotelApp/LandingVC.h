//
//  LandingVC.h
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VRGCalendarView.h"
#import "CustomCell.h"
#import "BMXSwitch.h"

@interface LandingVC : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UISearchBarDelegate,VRGCalendarViewDelegate,customCellDelegate>
{
    
    IBOutlet UIView *mainView;
    IBOutlet UITableView *visitorTableView;
    
    // IBOutlet UIView *topView;
    IBOutlet UIView *topView, *dataView, *leftView, *rightView, *addGuestView;
    
    
    
    //Sort View  Variables
    IBOutlet UIView *sortView;
    IBOutlet UIPickerView *sortPicker;
    IBOutlet UITextField *sortByTextField;
    IBOutlet UIButton *sortDropDownButton;
    BOOL sortDropDownBool;
    IBOutlet UIButton *cancelBtnSort, *doneBtnSort;
    UIView *dimViewSort;
    NSArray *sortArray;
    NSString *selectedUserIdString;
    
    
    IBOutlet UIButton *todayDropDownButton;
    
    //Check-in view widgets registered
    IBOutlet UIView *checkInView;
    IBOutlet UIImageView *guestIV;
    
    
    //Guest - RightView
    IBOutlet UILabel *guestNameLbl, *mobLbl, *emailLbl;
    IBOutlet UILabel *checkInLbl;
    IBOutlet UILabel *checkOutLbl;
    IBOutlet UILabel *checkInStatusLbl;
    
    IBOutlet UIButton *sendKeyBtn;
    IBOutlet UITextField *enterRoomTF, *checkInDateTF, *checkOutDateTF,*checkInTimeTF,*CheckOutTimeTF;
    
    
    
    
    
    
    //Access Swtiches
    IBOutlet BMXSwitch *meetingSwtich, *elevatorSwitch, *poolSwtich;
    IBOutlet BMXSwitch *agMeetingSwtich, *agElevatorSwitch, *agPoolSwtich;
    
    
    
    //SearchBar
    IBOutlet UISearchBar *searchBar;
    
    
    
    //Add Guest
    
    IBOutlet UIButton *addNewGuestBtn, *crossBtn;
    IBOutlet UIImageView *addImg;
    IBOutlet UITextField *agFnameTF, *agLnameTF, *agEmailTF, *agmobTF, *agroomNumberTF, *agcheckInDateTF, *agcheckOutDateTF,*agcheckInTimeTF,*agcheckOutTimeTF;
    
    IBOutlet UIButton *agAddGuestBtn, *agaddGuestSendKeyBtn;
    
    
    
    //Calendar View
    IBOutlet UIDatePicker   *datePicker;
    IBOutlet UIView *dateView;
    
    UIView *dimView;
    IBOutlet UIView *calendarUIView;
    IBOutlet UIButton *todayDateBtn;
    IBOutlet UIButton *cancelBtn, *doneBtn;
    
    
    IBOutlet UITextField *enterNameTF;
    
    
    //Sorting Dropdown tableView
    
    
}

@property (strong, nonatomic) NSMutableArray *visitorInfoArray;
@property (strong, nonatomic) NSMutableArray *mainDataArray;
@property (strong, nonatomic) NSMutableArray *tableDataArray;
@property (strong, nonatomic) NSMutableArray *tableDataArrayCopy;


-(IBAction)addNewGuest:(id)sender;



//Add Guest Actions
-(IBAction)agAddGuestBtnAction:(id)sender;                      //used for adding new guest
-(IBAction)agaddGuestSendKeyBtnAction:(id)sender;            //using for adding guest and sending
- (IBAction)sendKeyBtnTapped:(id)sender;                        // for sending key only

-(IBAction)todayDateBtnAction:(id)sender;                       //Today Btn, for date picker handling

-(IBAction)sortDropDownButtonTapped:(UIButton *)sender; //used for sorting Ascending and decending
-(IBAction)todayDropDownButtonTapped:(UIButton *)sender; //used for selecting guest by date





//switch methods
- (IBAction)valueChanged:(BMXSwitch *)sender;


- (IBAction)lockBtnTapped:(id)sender; //used for logout view

- (IBAction)resetBtnTapped:(id)sender; //used for Fetching guest

@end
