//
//  WebService.m
//  Barter
//
//  Created by Debut Infotech on 13/12/13.
//  Copyright (c) 2013 Debut Infotech. All rights reserved.
//



#import "WebService.h"
#import "JSON.h"

@interface WebService ()
@end

@implementation WebService

//Web Services Hitting Method called from Various Classes
#pragma mark - Web Service Method

- (NSMutableArray *) webServices :(NSMutableDictionary *) webDict : (NSString *)addUrl
{
    NSString *strUrl = [NSString stringWithFormat:@"%@/%@", WEBURL, addUrl];

    NSURL *url = [NSURL URLWithString:strUrl];

    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];

    NSError *error = NULL;

    NSLog(@"%@", strUrl);

    NSLog(@"%@", webDict);

    NSString *jsonString = [webDict JSONRepresentation];

    [request setHTTPMethod:@"POST"];

    [request setHTTPBody:[NSData dataWithBytes:[jsonString UTF8String] length:jsonString.length]];

    NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];

    NSMutableString *responseStr = [[NSMutableString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];

    NSMutableArray *arr = [[NSMutableArray alloc]init];

    arr = [responseStr JSONValue];
    NSLog(@"%@",[arr JSONRepresentation]);

    if (error == nil )
    {
        return arr;
    }
    else
    {
        [arr addObject:NULL];
        return arr;
    }
}

@end
