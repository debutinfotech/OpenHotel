//
//  AddGuestVC.h
//  OpenHotelApp
//
//  Created by Debut Infotech on 26/06/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddGuestVC : UIViewController

@end
