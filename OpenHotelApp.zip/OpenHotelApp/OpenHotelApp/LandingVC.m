//
//  LandingVC.m
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import "LandingVC.h"
#import "CustomCell.h"
#import "LoginVC.h"
#import "UITextField+CustomPlaceHolderTextColorTextField.h"
@interface LandingVC ()

@end

@implementation LandingVC
@synthesize mainDataArray, tableDataArray,tableDataArrayCopy;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self)
    {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    sortArray=[[NSArray alloc] initWithObjects:@" First Name",@" Last Name",@" Check In",@" Check Out", nil];
    
    sortDropDownBool=YES;
    
    rightView.layer.borderWidth = 1;
    rightView.layer.borderColor = [[UIColor colorWithRed:212.0/255.0 green:212.0/255.0 blue:212.0/255.0 alpha:1.0] CGColor];
    
    sendKeyBtn.layer.cornerRadius = 5.0f;
    agAddGuestBtn.layer.cornerRadius = 5.0f;
    agaddGuestSendKeyBtn.layer.cornerRadius = 5.0f;
    cancelBtn.layer.cornerRadius = 5.0f;
    doneBtn.layer.cornerRadius = 5.0f;
    
    guestIV.layer.cornerRadius = guestIV.bounds.size.width/2;
    
    guestIV.layer.masksToBounds = YES;
    [visitorTableView allowsMultipleSelectionDuringEditing];
    
    
    UIImageView *tempImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"fieldbg.png"]];
    [tempImageView setFrame:visitorTableView.frame];
    
    
    
    [self initAgSwitch]; //for on add guest screen
    [self initSwitch];  //for on add show guest screen
    
    
    
}
- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    
    
    self.visitorInfoArray = [[NSMutableArray alloc] init];
    
    [MMProgressHUD showWithTitle:@"Open Hotel" status:@"Loading..."];
}

-(void) viewDidAppear:(BOOL)animated{
    
    [self fetchGuestList];
    
}
#pragma mark -
- (IBAction)resetBtnTapped:(id)sender
{
    [self fetchGuestList]; //for fetching Guest List
    [todayDateBtn setTitle:@"All" forState:UIControlStateNormal];
    
}



-(void) fetchGuestList{
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    [mDict setObject:@"guest_list" forKey:@"method"];
    
    NSData *data = [[NSData alloc] initWithData:[[NSUserDefaults standardUserDefaults] objectForKey:@"userinfo"]];
    NSArray *arr = [[NSArray alloc] init];
    arr = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    [mDict setObject:[arr valueForKey:@"id"] forKey:@"recp_id"];
    [mDict setObject:[arr valueForKey:@"hotel_id"] forKey:@"hotel_id"];
    
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"guest/guest.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        [self.view endEditing:YES];
        
        self.visitorInfoArray = [[NSMutableArray alloc] initWithArray:[respArray valueForKey:@"resp"]];
        
        mainDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        
        tableDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        tableDataArrayCopy=[[NSMutableArray alloc]initWithArray:self.tableDataArray];
        
        [visitorTableView reloadData];
        
        [MMProgressHUD dismissWithSuccess:@"Success!"];
        
        //[self performSelector:@selector(goNext) withObject:nil afterDelay:1.3];
        
        [visitorTableView reloadData];
        [todayDateBtn setTitle:@"All" forState:UIControlStateNormal];
        // [self TodayDefautSorting];
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No records to display" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please Try Again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
}
#pragma mark - Add Guest send key Methods
-(IBAction)agaddGuestSendKeyBtnAction:(id)sender
{
    
    if (agFnameTF.text.length && agLnameTF.text.length && agEmailTF.text.length && agmobTF.text.length && agroomNumberTF.text.length && agroomNumberTF.text.length && agcheckInDateTF.text.length && agcheckOutDateTF.text.length && agcheckInTimeTF.text.length && agcheckOutTimeTF)
    {
        
        BOOL boolValue=[agEmailTF NSStringIsValidEmail:agEmailTF.text];
        if (!boolValue)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter valid email" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            agEmailTF.text=@"";
            [agEmailTF becomeFirstResponder];
        }
        else if (agmobTF.text.length<8)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Mobile number should be atleast 8 characters" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            agmobTF.text=@"";
            [agmobTF becomeFirstResponder];
        }
        else
        {
            [MMProgressHUD showWithTitle:@"Open Hotel" status:@"Loading..."];
            
            NSString *btnStr = @"guest_add";
            
            [self performSelector:@selector(addGuestSendKey:) withObject:btnStr afterDelay:0.5];
            
        }
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"error" message:@"All fields are required" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
    
    
}
-(void) addGuestSendKey:(NSString  *) method{
    
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    [mDict setObject:method forKey:@"method"];
    
    NSData *data = [[NSData alloc] initWithData:[[NSUserDefaults standardUserDefaults] objectForKey:@"userinfo"]];
    NSArray *arr = [[NSArray alloc] init];
    arr = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    [mDict setObject:[arr valueForKey:@"id"] forKey:@"recp_id"];
    [mDict setObject:[arr valueForKey:@"hotel_id"] forKey:@"hotel_id"];
    [mDict setObject:agFnameTF.text forKey:@"first_name"];
    [mDict setObject:agLnameTF.text forKey:@"last_name"];
    [mDict setObject:agEmailTF.text forKey:@"email"];
    [mDict setObject:agmobTF.text forKey:@"phone"];
    [mDict setObject:agcheckInDateTF.text forKey:@"check_in"];
    [mDict setObject:agcheckOutDateTF.text forKey:@"check_out"];
    [mDict setObject:agcheckInTimeTF.text forKey:@"check_in_time"];
    [mDict setObject:agcheckOutTimeTF.text forKey:@"check_out_time"];
    [mDict setObject:agroomNumberTF.text forKey:@"room"];
    [mDict setObject:@"1" forKey:@"send_key"];
    if (agElevatorSwitch.on)
    {
        [mDict setObject:@"1" forKey:@"elevator"];
    }
    else{
        [mDict setObject:@"0" forKey:@"elevator"];
    }
    
    if (agPoolSwtich.on)
    {
        [mDict setObject:@"1" forKey:@"pool"];
    }
    else{
        [mDict setObject:@"0" forKey:@"pool"];
    }
    
    if (agMeetingSwtich.on)
    {
        [mDict setObject:@"1" forKey:@"meeting_room"];
    }
    else
    {
        [mDict setObject:@"0" forKey:@"meeting_room"];
    }
    
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"guest/guest.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        [self.view endEditing:YES];
        
        self.visitorInfoArray = [[NSMutableArray alloc] initWithArray:[respArray valueForKey:@"resp"]];
        
        mainDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        
        tableDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        
        [visitorTableView reloadData];
        
        [MMProgressHUD dismissWithSuccess:@"Success!"];
        [self emptyAllTheTextField];
        
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[respArray valueForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
}

#pragma mark - send key Methods
- (IBAction)sendKeyBtnTapped:(id)sender
{
    
    if (enterNameTF.text && enterNameTF.text.length && enterRoomTF.text && enterRoomTF.text.length)
    {
        
        NSDate *currentDate = [NSDate date];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        
        //[dateFormat setDateFormat:@"HH:mm:a"];
        
        [dateFormat setDateFormat:@"dd/MM/yyyy"];
        NSString *currentDateString = [dateFormat stringFromDate:currentDate];
        NSDate *currentDateOnly=[dateFormat dateFromString:currentDateString];
        
        
        NSDate *checkOutDate=[dateFormat dateFromString:checkOutDateTF.text];
        
        
        
        if ([currentDateOnly compare:checkOutDate]==NSOrderedAscending || [currentDateOnly compare:checkOutDate]==NSOrderedSame)
        {
            
            if (![currentDateOnly compare:checkOutDate]==NSOrderedSame) //No need to time comparsion
            {
                [self sendKeyMethod];
            }
            else
            {
                NSDate *currentTime = [NSDate date];
                NSDateFormatter *dateFormatForTime = [[NSDateFormatter alloc] init];
                
                [dateFormatForTime setDateFormat:@"hh:mm:a"];
                NSString *currentTimeString = [dateFormatForTime stringFromDate:currentTime];
                NSDate *currentTimeOnly=[dateFormatForTime dateFromString:currentTimeString];
                NSDate *checkOutTime=[dateFormatForTime dateFromString:CheckOutTimeTF.text];
                
                if ([currentTimeOnly compare:checkOutTime]==NSOrderedAscending || [currentTimeOnly compare:checkOutTime]== NSOrderedSame)
                {
                    [self sendKeyMethod];
                }
                else
                {
                    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"User is already checked out" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
                    [alert show];
                }
                
            }
            
            
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"User is already checked out" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
        }
        
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please fill all the Inputs" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
    
    
}

-(void)sendKeyMethod
{
    [MMProgressHUD show];
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    [mDict setObject:@"send_key" forKey:@"method"];
    NSPredicate *predicate=[NSPredicate predicateWithFormat:@"id=%@",selectedUserIdString];
    NSArray *tableDataArrayCopy=[[tableDataArray filteredArrayUsingPredicate:predicate]mutableCopy];
    if (tableDataArrayCopy.count)
    {
        
        NSMutableDictionary *selectedDict=[tableDataArrayCopy objectAtIndex:0];
        NSLog(@"tabledata %@",selectedDict);
        
        [mDict setObject:enterNameTF.text forKey:@"username"];
        
        [mDict setObject:[selectedDict valueForKey:@"phone"] forKey:@"phone"];
        [mDict setObject:[selectedDict valueForKey:@"id"] forKey:@"id"];
        
        if (elevatorSwitch.on)
        {
            [mDict setObject:@"1" forKey:@"elevator"];
        }
        else{
            [mDict setObject:@"0" forKey:@"elevator"];
        }
        
        if (poolSwtich.on)
        {
            [mDict setObject:@"1" forKey:@"pool"];
        }
        else{
            [mDict setObject:@"0" forKey:@"pool"];
        }
        
        if (meetingSwtich.on)
        {
            [mDict setObject:@"1" forKey:@"meeting_room"];
        }
        else
        {
            [mDict setObject:@"0" forKey:@"meeting_room"];
        }
        
        [mDict setObject:[selectedDict valueForKey:@"room_number"] forKey:@"room_number"];
        [mDict setObject:[selectedDict valueForKey:@"email"] forKey:@"email"];
    }
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"guest/guest.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        [self.view endEditing:YES];
        
        [MMProgressHUD dismissWithSuccess:@"Key is successfully sent"];
        
        
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    
}
#pragma mark - For Selecting add New Guset Screen Methods
-(IBAction)addNewGuest:(UIButton *)sender
{
    if(sender.tag == 1){
        
        sender.tag = 0;
        
        
        
        [addNewGuestBtn setTitle:@"Done" forState:UIControlStateNormal];
        addImg.hidden = TRUE;
        
        [UIView transitionWithView:rightView
                          duration:1.0
                           options:UIViewAnimationOptionTransitionCurlUp
                        animations:^{
                            //rightView.hidden = TRUE;
                            [self performSelector:@selector(unhideView) withObject:nil afterDelay:0.4];
                            rightView.hidden = true;
                        }
                        completion:nil];
        
        
    }
    else{
        
        sender.tag = 1;
        
        [addNewGuestBtn setTitle:@"Add New Guest" forState:UIControlStateNormal];
        addImg.hidden = FALSE;
        
        [UIView transitionWithView:rightView
                          duration:1.0
                           options:UIViewAnimationOptionTransitionCurlDown
                        animations:^{
                            [self performSelector:@selector(hideView) withObject:nil afterDelay:1.0];
                            rightView.hidden = false;
                            
                        }
                        completion:nil];
        
        
        
    }
    
    crossBtn.tag= sender.tag;
    addNewGuestBtn.tag = sender.tag;
}
-(void) hideView
{
    rightView.hidden = false;
}
-(void)unhideView
{
    rightView.hidden = true;
}


#pragma mark - Add Guest Methods

-(IBAction)agAddGuestBtnAction:(UIButton *)sender{
    if (agFnameTF.text.length && agLnameTF.text.length && agEmailTF.text.length && agmobTF.text.length && agroomNumberTF.text.length && agroomNumberTF.text.length && agcheckInDateTF.text.length && agcheckOutDateTF.text.length && agcheckInTimeTF.text.length && agcheckOutTimeTF)
    {
        
        BOOL boolValue=[agEmailTF NSStringIsValidEmail:agEmailTF.text];
        if (!boolValue)
        {
            
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter valid email" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            agEmailTF.text=@"";
            [agEmailTF becomeFirstResponder];
            
            
        }
        else if (agmobTF.text.length<8)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Mobile number should be atleast 8 characters" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            agmobTF.text=@"";
            [agmobTF becomeFirstResponder];
        }
        else
        {
            
            [MMProgressHUD showWithTitle:@"Open Hotel" status:@"Loading..."];
            
            NSString *btnStr = @"";
            if (sender.tag == 1) {
                btnStr = @"guest_add";
            }
            else{
                btnStr = @"Add_Send_Key";
            }
            [self performSelector:@selector(addGuest:) withObject:btnStr afterDelay:0.5];
        }
        
        
        
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"All fields are required" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
    
    
    
    
}

-(void) addGuest:(NSString  *) method
{
    
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    [mDict setObject:method forKey:@"method"];
    
    NSData *data = [[NSData alloc] initWithData:[[NSUserDefaults standardUserDefaults] objectForKey:@"userinfo"]];
    NSArray *arr = [[NSArray alloc] init];
    arr = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    [mDict setObject:[arr valueForKey:@"id"] forKey:@"recp_id"];
    [mDict setObject:[arr valueForKey:@"hotel_id"] forKey:@"hotel_id"];
    [mDict setObject:agFnameTF.text forKey:@"first_name"];
    [mDict setObject:agLnameTF.text forKey:@"last_name"];
    [mDict setObject:agEmailTF.text forKey:@"email"];
    [mDict setObject:agmobTF.text forKey:@"phone"];
    [mDict setObject:agcheckInDateTF.text forKey:@"check_in"];
    [mDict setObject:agcheckOutDateTF.text forKey:@"check_out"];
    
    [mDict setObject:agcheckInTimeTF.text forKey:@"check_in_time"];
    [mDict setObject:agcheckOutTimeTF.text forKey:@"check_out_time"];
    [mDict setObject:agroomNumberTF.text forKey:@"room"];
    
    
    
    
    if (agElevatorSwitch.on)
    {
        [mDict setObject:@"1" forKey:@"elevator"];
    }
    else{
        [mDict setObject:@"0" forKey:@"elevator"];
    }
    
    if (agPoolSwtich.on)
    {
        [mDict setObject:@"1" forKey:@"pool"];
    }
    else{
        [mDict setObject:@"0" forKey:@"pool"];
    }
    
    if (agMeetingSwtich.on)
    {
        [mDict setObject:@"1" forKey:@"meeting_room"];
    }
    else
    {
        [mDict setObject:@"0" forKey:@"meeting_room"];
    }
    
    
    
    
    
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"guest/guest.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        [self.view endEditing:YES];
        
        self.visitorInfoArray = [[NSMutableArray alloc] initWithArray:[respArray valueForKey:@"resp"]];
        
        mainDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        
        tableDataArray = [[NSMutableArray alloc] initWithArray:self.visitorInfoArray];
        
        [visitorTableView reloadData];
        
        [MMProgressHUD dismissWithSuccess:@"Success!"];
        [todayDateBtn setTitle:@"All" forState:UIControlStateNormal];
        [self emptyAllTheTextField];
        
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[respArray valueForKey:@"msg"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
        
        
    }
    
    
}



-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [searchBar resignFirstResponder];
    [self.view endEditing:YES];
    [visitorTableView endEditing:YES];
    [leftView endEditing:YES];
    
    [super touchesBegan:touches withEvent:event];
    
    
}
#pragma mark - UITextfield Delegate
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [self.view endEditing:YES];
    
    
    if (textField == agFnameTF) {
        [agLnameTF becomeFirstResponder];
        return YES;
    }
    else if (textField == agLnameTF){
        [agEmailTF becomeFirstResponder];
        return YES;
    }
    else if (textField == agEmailTF){
        
        BOOL boolValue=[textField NSStringIsValidEmail:textField.text];
        if (!boolValue)
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter valid email" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            agEmailTF.text=@"";
            [agEmailTF becomeFirstResponder];
        }
        else
        {
            [agmobTF becomeFirstResponder];
        }
        
        
        
        return YES;
    }
    else if (textField == agmobTF){
        [agroomNumberTF becomeFirstResponder];
        return YES;
    }
    else if (textField == agroomNumberTF){
        //[agcheckInDateTF becomeFirstResponder];
        return YES;
    }
    if (textField == enterNameTF) {
        [enterRoomTF becomeFirstResponder];
        return YES;
    }
    
    return NO;
    
}

-(BOOL) textFieldShouldBeginEditing:(UITextField *)textField
{
    doneBtn.tag= 1;
    cancelBtn.tag = 1;
    
    [self.view endEditing:YES];
    
    
    if (textField == agcheckInDateTF || textField == agcheckOutDateTF || textField==checkInDateTF ||  textField==checkOutDateTF || textField==CheckOutTimeTF || textField==checkInTimeTF || textField==agcheckInTimeTF || textField==agcheckOutTimeTF)
    {
        if (textField == agcheckInDateTF) {
            doneBtn.tag= 1;
            cancelBtn.tag = 1;
        }
        else if(textField==agcheckOutDateTF)
        {
            doneBtn.tag= 2;
            cancelBtn.tag = 2;
        }
        else if(textField==checkInDateTF)
        {
            doneBtn.tag= 4;
            cancelBtn.tag = 4;
        }
        else if(textField==checkOutDateTF)
        {
            
            doneBtn.tag= 5;
            cancelBtn.tag = 5;
        }
        else if(textField==checkInTimeTF)
        {
            
            doneBtn.tag= 6;
            cancelBtn.tag = 6;
        }
        else if(textField==CheckOutTimeTF)
        {
            
            doneBtn.tag=7;
            cancelBtn.tag = 7;
        }
        else if(textField==agcheckInTimeTF)
        {
            
            doneBtn.tag=8;
            cancelBtn.tag = 8;
        }
        else if(textField==agcheckOutTimeTF)
        {
            
            doneBtn.tag=9;
            cancelBtn.tag = 9;
        }
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        if (textField==checkInTimeTF ||textField==CheckOutTimeTF || textField==agcheckInTimeTF || textField==agcheckOutTimeTF )
        {
            [datePicker setDatePickerMode:UIDatePickerModeTime];
            [dateFormat setDateFormat:@"hh:mm:a"];
        }
        else
        {
            [datePicker setDatePickerMode:UIDatePickerModeDate];
            [dateFormat setDateFormat:@"dd/MM/yyyy"];
        }
        
        [self addCalendar:textField.text :textField: nil];
        
        
        
        
        if (![textField.text isEqualToString:@""]) {
            
            NSDate *date = [[ NSDate alloc] init];
            
            date = [dateFormat dateFromString:textField.text];
            
            [datePicker setDate:date];
        }
        
    }
    else if (textField==sortByTextField)
    {
        
        
        doneBtnSort.tag= 3;
        cancelBtnSort.tag = 3;
        
        [sortDropDownButton setSelected:YES];
        [self addSortView:textField.text :textField: nil];
        
        
        
    }
    else{
        return YES;
    }
    
    
    
    
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == agFnameTF)
    {
        if (agFnameTF.text.length>=20)
        {
            [textField resignFirstResponder];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too big"
                                                            message:@"Please shorten name"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            return NO;
        }
        else
        {
            NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz "] invertedSet]; ;
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
            //  return [string isEqualToString:filtered];
            if ([string isEqualToString:filtered])
            {
                return YES;
            }
            else
            {
                UIAlertView *alert  =[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter only alphabetic character" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
                [alert show];
                return NO;
            }
        }
    }
    else if(textField==agLnameTF)
    {
        if (agLnameTF.text.length>=20)
        {
            [textField resignFirstResponder];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too big"
                                                            message:@"Please shorten name"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            return NO;
        }
        else
        {
            
            
            NSCharacterSet *invalidCharSet = [[NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz "] invertedSet]; ;
            NSString *filtered = [[string componentsSeparatedByCharactersInSet:invalidCharSet] componentsJoinedByString:@""];
            //  return [string isEqualToString:filtered];
            if ([string isEqualToString:filtered])
            {
                return YES;
            }
            else
            {
                UIAlertView *alert  =[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter only alphabetic character" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
                [alert show];
                return NO;
            }
            
        }
        
    }
    else if (textField == agEmailTF)
    {
        
        if (agEmailTF.text.length>=50)
        {
            [textField resignFirstResponder];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too big"
                                                            message:@"Please shorten name"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            return NO;
        }
    }
    
    else if (textField == agmobTF)
    {
        if (agmobTF.text.length>=12)
        {
            [textField resignFirstResponder];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too big"
                                                            message:@"Please shorten name"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            return NO;
        }
        else
        {
            NSCharacterSet *numbersOnly = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
            NSCharacterSet *characterSetFromTextField = [NSCharacterSet characterSetWithCharactersInString:string];
            
            BOOL stringIsValid = [numbersOnly isSupersetOfSet:characterSetFromTextField];
            if (stringIsValid)
            {
                return YES;
            }
            else
            {
                NSString *messageString;
                if (textField==agmobTF)
                {
                    messageString=@"Please enter numeric value";
                }
                if (textField==agroomNumberTF)
                {
                    messageString=@"Please enter valid numeric value";
                }
                
                UIAlertView *alert  =[[UIAlertView alloc]initWithTitle:@"Error" message:[NSString stringWithFormat:@"%@",messageString] delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
                [alert show];
                return NO;
                
            }
            
        }
    }
    
    else if (textField==agroomNumberTF)
    {
        if (agroomNumberTF.text.length>=20)
        {
            [textField resignFirstResponder];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Too big"
                                                            message:@"Please shorten name"
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
            [alert show];
            return NO;
        }
    }
    
    else
    {
        return YES;
    }
    return YES;
}
-(void)emptyAllTheTextField
{
    agFnameTF.text=@"";
    agLnameTF.text=@"";
    agmobTF.text=@"";
    agroomNumberTF.text=@"";
    agEmailTF.text=@"";
    agcheckInDateTF.text=@"";
    agcheckOutDateTF.text=@"";
    agcheckInTimeTF.text=@"";
    agcheckOutTimeTF.text=@"";
    
    agMeetingSwtich.on=NO;
    agElevatorSwitch.on=NO;
    agPoolSwtich.on=NO;
    
}


#pragma mark - Picker View Delegate Function

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [sortArray count];
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [sortArray objectAtIndex:row];
}




-(void) addCalendar:(NSString *) valueStr :(UITextField *) textField : (UIButton *) button
{
    [dateView.layer setBorderColor:[[UIColor colorWithRed:212.0/255.0 green:212.0/255.0 blue:212.0/255.0 alpha:1.0] CGColor]];
    [dateView.layer setBorderWidth: 1.5f];
    dateView.layer.masksToBounds = YES;
    dateView.clipsToBounds = YES;
    
    dimView = [[UIView alloc]initWithFrame:self.view.frame];
    dimView.backgroundColor = [UIColor blackColor];
    dimView.alpha = 0;
    [self.view addSubview:dimView];
    [self.view bringSubviewToFront:dimView];
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         dimView.alpha = 0.4;
                     }];
    
    [self.view addSubview:dateView];
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        if ([[UIScreen mainScreen] bounds].size.height > 480.0f)
        {
            // updateView.frame = CGRectMake(20, 160, 280,191 );
            // updateImageView.frame = CGRectMake(0, 0, 280,191 );
        }
        else
        {
            // updateView.frame = CGRectMake(20, 140, 280,191);
            //  updateImageView.frame = CGRectMake(0, 0, 280,191 );
        }
    }
    else
    {
        dateView.frame = CGRectMake(278, 239, dateView.frame.size.width,dateView.frame.size.height );
    }
    
    
    
    
}
-(void)TodayDefautSorting
{
    NSDate *currentDate = [[NSDate alloc]init];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    //[dateFormat setDateFormat:@"HH:mm:a"];
    
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    NSString *currentDateString = [dateFormat stringFromDate:currentDate];
    [self searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)[NSString stringWithFormat:@"%@", currentDateString]];
}
-(IBAction)todayDateBtnAction1:(UIButton *)sender
{
    doneBtn.tag= 0;
    cancelBtn.tag = 0;
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [datePicker setDatePickerMode:UIDatePickerModeDate];
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    NSDate *date = [[ NSDate alloc] init];
    [datePicker setDate:date];
    [self addCalendar:sender.titleLabel.text :nil :sender];
}


-(IBAction) viewBackBtnTapped:(UIButton *)sender
{
    [UIView animateWithDuration:0.3
                     animations:^{
                         dimView.alpha = 0;
                     }];
    
    [dimView removeFromSuperview];
    dimView = nil;
    
    [dateView removeFromSuperview];
    NSLog(@"%d",sender.tag);
    if (sender.tag==1)
    {
        // [self performSelector:@selector(showCheckOut) withObject:nil afterDelay:.4];
    }
    
    
}
-(void)showCheckOut
{
    // [agcheckOutDateTF becomeFirstResponder];
}
-(IBAction)todayDropDownButtonTapped:(UIButton *)sender
{
    if (sender.selected)
    {
        sender.selected=NO;
        //  sortDropDownBool=YES;
        // [self sortArrayBySortSelection];
    }
    else
    {
        sender.selected=YES;
        //sortDropDownBool=NO;
        // [self sortArrayBySortSelection];
    }
    
    
}
#pragma mark - Sorting view Function
-(void) addSortView:(NSString *) valueStr :(UITextField *) textField : (UIButton *) button
{
    [sortView.layer setBorderColor:[[UIColor colorWithRed:212.0/255.0 green:212.0/255.0 blue:212.0/255.0 alpha:1.0] CGColor]];
    [sortView.layer setBorderWidth: 1.5f];
    sortView.layer.masksToBounds = YES;
    sortView.clipsToBounds = YES;
    
    dimViewSort = [[UIView alloc]initWithFrame:self.view.frame];
    dimViewSort.backgroundColor = [UIColor blackColor];
    dimViewSort.alpha = 0;
    [self.view addSubview:dimViewSort];
    [self.view bringSubviewToFront:dimViewSort];
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         dimViewSort.alpha = 0.4;
                     }];
    
    
    
    
    [self.view addSubview:sortView];
    [self.view endEditing:YES];
    
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
    {
        if ([[UIScreen mainScreen] bounds].size.height > 480.0f)
        {
            // updateView.frame = CGRectMake(20, 160, 280,191 );
            // updateImageView.frame = CGRectMake(0, 0, 280,191 );
        }
        else
        {
            // updateView.frame = CGRectMake(20, 140, 280,191);
            //  updateImageView.frame = CGRectMake(0, 0, 280,191 );
        }
    }
    else
    {
        sortView.frame = CGRectMake(278, 239, dateView.frame.size.width,dateView.frame.size.height );
    }
    
    
    
    
}

-(void)sortArrayBySortSelection
{
    
    if ([sortByTextField.text isEqual:@" First Name"])
    {
        NSLog(@"bool value %hhd",sortDropDownButton.selected);
        NSSortDescriptor *ageDescriptor=[[NSSortDescriptor alloc] initWithKey:@"first_name" ascending:sortDropDownBool];
        
        
        NSArray *sortDescriptors = @[ageDescriptor];
        tableDataArray = [[tableDataArray sortedArrayUsingDescriptors:sortDescriptors]mutableCopy];
        [visitorTableView reloadData];
    }
    else if ([sortByTextField.text isEqual:@" Last Name"])
    {
        NSSortDescriptor *ageDescriptor = [[NSSortDescriptor alloc] initWithKey:@"last_name" ascending:sortDropDownBool];
        NSArray *sortDescriptors = @[ageDescriptor];
        tableDataArray = [[tableDataArray sortedArrayUsingDescriptors:sortDescriptors]mutableCopy];
        [visitorTableView reloadData];
    }
    else if ([sortByTextField.text isEqual:@" Check In"])
    {
        NSSortDescriptor *ageDescriptor = [[NSSortDescriptor alloc] initWithKey:@"check_in" ascending:sortDropDownBool];
        NSArray *sortDescriptors = @[ageDescriptor];
        tableDataArray = [[tableDataArray sortedArrayUsingDescriptors:sortDescriptors]mutableCopy];
        [visitorTableView reloadData];
    }
    else if ([sortByTextField.text isEqual:@"Check Out"])
    {
        NSSortDescriptor *ageDescriptor = [[NSSortDescriptor alloc] initWithKey:@"check_out" ascending:sortDropDownBool];
        NSArray *sortDescriptors = @[ageDescriptor];
        tableDataArray = [[tableDataArray sortedArrayUsingDescriptors:sortDescriptors]mutableCopy ];
        [visitorTableView reloadData];
    }
    
    
}
-(NSMutableArray *)sortArrayBasedOndate:(NSMutableArray *)arraytoSort
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"dd/MM/yyyy"];
    
    NSComparator compareDates = ^(id string1, id string2)
    {
        NSDate *date1 = [formatter dateFromString:string1];
        NSDate *date2 = [formatter dateFromString:string2];
        
        return [date1 compare:date2];
    };
    
    
    NSSortDescriptor * sortDesc1 = [[NSSortDescriptor alloc] initWithKey:@"start_date" ascending:YES comparator:compareDates];
    [arraytoSort sortUsingDescriptors:[NSArray arrayWithObjects:sortDesc1, nil]];
    
    
    return arraytoSort;
}
-(IBAction) viewBackBtnForSortViewTapped:(UIButton *)sender
{
    [UIView animateWithDuration:0.3
                     animations:^{
                         dimView.alpha = 0;
                     }];
    [dimViewSort removeFromSuperview];
    dimViewSort = nil;
    [sortView removeFromSuperview];
    
}
-(IBAction)cancelBtnOfSortViewTapped:(UIButton *)sender
{
    [self viewBackBtnForSortViewTapped:nil];
}
-(IBAction)doneBtnOfSortViewTapped:(UIButton *)sender
{
    sortByTextField.text=[sortArray objectAtIndex:[sortPicker selectedRowInComponent:0] ];
    [self sortArrayBySortSelection];
    [sortDropDownButton setSelected:NO];
    [self viewBackBtnForSortViewTapped:nil];
    
    
}
-(IBAction)sortDropDownButtonTapped:(UIButton *)sender
{
    if (sender.selected)
    {
        sender.selected=NO;
        sortDropDownBool=YES;
        [self sortArrayBySortSelection];
    }
    else
    {
        sender.selected=YES;
        sortDropDownBool=NO;
        [self sortArrayBySortSelection];
    }
    
    
    
}



#pragma mark - Methods of Date Picker View Function

-(IBAction)cancelBtnTapped:(UIButton *)sender
{
    if (sender.tag == 0) {
        
        //  [todayDateBtn setTitle:@"Today" forState:UIControlStateNormal];
        //[self TodayDefautSorting];
        [dateView removeFromSuperview];
    }
    else{
        
    }
    
    [self viewBackBtnTapped:nil];
    
}


-(IBAction)doneBtnTapped:(UIButton *)sender
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    if (sender.tag==6 || sender.tag==7 || sender.tag==8 || sender.tag==9)
    {
        [dateFormat setDateFormat:@"hh:mm:a"];
    }
    else
    {
        [dateFormat setDateFormat:@"dd/MM/yyyy"];
    }
    
    
    
    NSString *theDate = [dateFormat stringFromDate:datePicker.date];
    
    if (sender.tag == 0) {
        
        [todayDateBtn setTitle:[NSString stringWithFormat:@"%@", theDate] forState:UIControlStateNormal];
        
        [self searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)[NSString stringWithFormat:@"%@", theDate]];
        
    }
    else if(sender.tag == 1){
        // agcheckInDateTF.text = [NSString stringWithFormat:@"%@", theDate];
        [self agComparingCheckinDate:theDate];
    }
    else if(sender.tag == 2){
        
        [self agComparingCheckOutDate:theDate];
    }
    else if(sender.tag == 4){
        checkInDateTF.text = [NSString stringWithFormat:@"%@", theDate];
        
    }
    else if(sender.tag == 5){
        checkOutDateTF.text = [NSString stringWithFormat:@"%@", theDate];
        
    }
    else if(sender.tag == 6){
        
        checkInTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
    }
    else if(sender.tag == 7){
        CheckOutTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
    }
    else if(sender.tag == 8){
        agcheckInTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
        agcheckOutTimeTF.text=@"";
        
    }
    else if(sender.tag == 9){
        //agcheckOutTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
        
        if (agcheckInDateTF.text && agcheckInDateTF.text.length )
        {
            if (agcheckOutDateTF.text.length)
            {
                if ([self CompareIsCheckOutDateAndCheckInDate])
                {
                    agcheckOutTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
                    
                }
                else
                {
                    [self comparingCheckOutTime:theDate];
                }
                
            }
            else
            {
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"First select check out Date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
                [alert show];
            }
            
            
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"First select check in Date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
        }
        
        
        
    }
    
    [self viewBackBtnTapped:sender];
    
}


#pragma mark - Selecting Right Date or Comparing Date Function

-(void)agComparingCheckinDate:(NSString*)theDate
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    //[dateFormat setDateFormat:@"HH:mm:a"];
    
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    
    NSDate *agCheckoutDate = [dateFormat dateFromString:theDate];
    
    
    NSDate *currentDate=[[NSDate alloc]init];
    NSString *currentDateString=[dateFormat stringFromDate:currentDate];
    NSDate *currentDateOnly=[dateFormat dateFromString:currentDateString];
    
    if ([currentDateOnly compare:agCheckoutDate]==NSOrderedAscending || [currentDateOnly compare:agCheckoutDate]==NSOrderedSame)
    {
        
        agcheckInDateTF.text = [NSString stringWithFormat:@"%@", theDate];
        agcheckOutDateTF.text=@"";
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"check in date should be greater than or equal to current date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
    
}
-(void)agComparingCheckOutDate:(NSString*)theDate
{
    if (agcheckInDateTF.text && agcheckInDateTF.text.length)
    {
        
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        
        //[dateFormat setDateFormat:@"HH:mm:a"];
        
        [dateFormat setDateFormat:@"dd/MM/yyyy"];
        
        NSDate *agCheckoutDate = [dateFormat dateFromString:theDate];
        NSString *agCheckoutDateString = [dateFormat stringFromDate:agCheckoutDate];
        NSDate *currentCheckoutDateOnly=[dateFormat dateFromString:agCheckoutDateString];
        
        
        NSDate *agcheckInDate=[dateFormat dateFromString:agcheckInDateTF.text];
        
        
        
        if ([agcheckInDate compare:currentCheckoutDateOnly]==NSOrderedAscending || [agcheckInDate compare:currentCheckoutDateOnly]==NSOrderedSame)
        {
            
            agcheckOutDateTF.text = [NSString stringWithFormat:@"%@", theDate];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"check out date should be greater than check in date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
        }
        
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"First select check in Date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
    
}


-(void)comparingCheckOutTime:(NSString*)theDate
{
    
    if (agcheckInTimeTF.text && agcheckInTimeTF.text.length)
    {
        
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        
        //[dateFormat setDateFormat:@"HH:mm:a"];
        
        [dateFormat setDateFormat:@"hh:mm:a"];
        
        NSDate *agCheckoutTime = [dateFormat dateFromString:theDate];
        NSString *agCheckoutTimeString = [dateFormat stringFromDate:agCheckoutTime];
        NSDate *checkoutTimeOnly=[dateFormat dateFromString:agCheckoutTimeString];
        
        
        NSDate *agcheckInTime=[dateFormat dateFromString:agcheckInTimeTF.text];
        
        
        
        if ([agcheckInTime compare:checkoutTimeOnly]==NSOrderedAscending || [agcheckInTime compare:checkoutTimeOnly]==NSOrderedSame)
        {
            
            agcheckOutTimeTF.text = [NSString stringWithFormat:@"%@", theDate];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Check out time should be greater than check in time" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
        }
        
    }
    else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"First select check in time" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alert show];
    }
}
-(BOOL)CompareIsCheckOutDateAndCheckInDate
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    //[dateFormat setDateFormat:@"HH:mm:a"];
    
    [dateFormat setDateFormat:@"dd/MM/yyyy"];
    
    NSDate *agCheckoutDate = [dateFormat dateFromString:agcheckOutDateTF.text];
    NSString *agCheckoutDateString = [dateFormat stringFromDate:agCheckoutDate];
    NSDate *currentCheckoutDateOnly=[dateFormat dateFromString:agCheckoutDateString];
    
    
    NSDate *agcheckInDate=[dateFormat dateFromString:agcheckInDateTF.text];
    
    
    
    if ([agcheckInDate compare:currentCheckoutDateOnly]==NSOrderedAscending)
    {
        
        return YES;
        //  agcheckOutDateTF.text = [NSString stringWithFormat:@"%@", agcheckOutDateTF.text];
        
        
    }
    else
    {
        return NO;
        // UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"error" message:@"check out date should be greater than check in date" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        //[alert show];
    }
    
    
    return NO;
    
}


#pragma mark - Search Bar Delegates
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSMutableArray *foundArray = [[NSMutableArray alloc] init];
    
    NSLog(@"%@", searchText);
    
    BOOL found = FALSE;
    
    for (int i=0; i<self.mainDataArray.count; i++) {
        
        //Check for searching via firstname, lastname, mobile and email
        if ([[[self.mainDataArray objectAtIndex:i] valueForKey:@"first_name"] rangeOfString:searchText options:NSCaseInsensitiveSearch].location != NSNotFound ||  [[[self.mainDataArray objectAtIndex:i] valueForKey:@"last_name"] rangeOfString:searchText options:NSCaseInsensitiveSearch].location != NSNotFound ||  [[[self.mainDataArray objectAtIndex:i] valueForKey:@"phone"] rangeOfString:searchText options:NSCaseInsensitiveSearch].location != NSNotFound ||  [[[self.mainDataArray objectAtIndex:i] valueForKey:@"email"] rangeOfString:searchText options:NSCaseInsensitiveSearch].location != NSNotFound ||  [[[self.mainDataArray objectAtIndex:i] valueForKey:@"check_in"] rangeOfString:searchText options:NSCaseInsensitiveSearch].location != NSNotFound)
        {
            [foundArray addObject:[self.mainDataArray objectAtIndex:i]];
            found = TRUE;
        }
    }
    if (![searchText isEqualToString:@""]) {
        if (found == FALSE)
        {
            NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
            
            [dict setValue:@"No Guest Found" forKey:@"first_name"];
            [dict setValue:@"" forKey:@"last_name"];
            [dict setValue:@"xxxxxxxx" forKey:@"phone"];
            [dict setValue:@"" forKey:@"check_in"];
            [dict setValue:@"" forKey:@"check_out"];
            
            [foundArray addObject:dict];
            
            self.tableDataArray =foundArray;
        }
        else{
            self.tableDataArray =foundArray;
        }
    }
    else
    {
        self.tableDataArray = self.mainDataArray ;
        [self sortArrayBySortSelection];
        //tableDataArray=[self sortArrayBasedOndate:tableDataArray];
    }
    
    [visitorTableView reloadData];
}

#pragma mark - DSLCalendarViewDelegate methods
-(void)calendarView:(VRGCalendarView *)calendarView switchedToMonth:(int)month targetHeight:(float)targetHeight animated:(BOOL)animated
{
    //    if (month==[[NSDate date] month]) {
    //        NSArray *dates = [NSArray arrayWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:5], nil];
    //        [calendarView markDates:dates];
    //    }
    
    //    NSArray *dates = [NSArray arrayWithObjects:[NSNumber numberWithInt:1],[NSNumber numberWithInt:5], nil];
    //
    //    NSDate *date = [[NSDate alloc] init];
    //
    //    [calendarView selectDate:11];
}

-(void)calendarView:(VRGCalendarView *)calendarView dateSelected:(NSDate *)date {
    NSLog(@"Selected date = %@",date);
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"dd/MM/yyyy"];
    
    [todayDateBtn setTitle:[NSString stringWithFormat:@"%@",[format stringFromDate:date]] forState:UIControlStateNormal];
    
    calendarUIView.hidden = true;
}



#pragma mark - Tableview Delegates
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //---check the current year based on the section index---
    return [self.tableDataArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *customCellIdentifier = @"CustomCell";
    
    CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:customCellIdentifier];
    
	if(cell == nil)
    {
        NSArray *topLevelObjects;
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        {
            if ([[UIScreen mainScreen] bounds].size.height > 480.0f)
            {
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
            }
            else
            {
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
            }
        }
        else
        {
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
        }
        
        for(id currentObject in topLevelObjects)
        {
            if([currentObject isKindOfClass:[UITableViewCell class]])
            {
                cell = (CustomCell *)currentObject;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
        }
        
        cell.guestNameLbl.text = [NSString stringWithFormat:@"%@ %@",[[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"first_name"], [[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"last_name"]];
        
        cell.dateLbl.text = [NSString stringWithFormat:@"%@\n%@", [[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"check_in"], [[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"check_out"]];
        
        cell.mobileLbl.text = [[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"phone"];
        
        if ([[[self.tableDataArray objectAtIndex:indexPath.row] valueForKey:@"check_in_status"] isEqualToString:@"0"])
        {
            cell.circleIV.hidden = false;
        }
    }
    
    
    if (tableDataArray.count)
    {
        if (indexPath.row==0)
        {
            [self checkIn:0];
        }
    }
    cell.delegate=self;
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    
    
    return cell;
}




- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        if ([[UIScreen mainScreen] bounds].size.height > 480.0f)
        {
            return 50;
        }
        else
        {
            return 50;
        }
    }
    else
    {
        return 62;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [searchBar resignFirstResponder];
    
    [self checkIn:(int)indexPath.row];
    
    NSIndexPath *selected = [visitorTableView indexPathForSelectedRow];
    
    if (selected) {
        
        [visitorTableView deselectRowAtIndexPath:selected animated:YES];
    }
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //add code here for when you hit delete
        if (tableDataArray.count)
        {
            NSMutableDictionary *deletedDict=[tableDataArray objectAtIndex:indexPath.row];
            [self deleteGuestFromList:deletedDict];
            [self fetchGuestList];
            
        }
        
        
        
        
        
    }
}



-(void)deleteGuestFromList:(NSMutableDictionary*)deletedDict
{
    
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    [mDict setObject:@"guest_delete" forKey:@"method"];
    
    NSData *data = [[NSData alloc] initWithData:[[NSUserDefaults standardUserDefaults] objectForKey:@"userinfo"]];
    NSArray *arr = [[NSArray alloc] init];
    arr = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    [mDict setObject:[deletedDict valueForKey:@"id"] forKey:@"guest_id"];
    
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"guest/guest.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        [MMProgressHUD dismissWithSuccess:@"Guest is deleted successfully"];
        
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Please try again" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
    }
}


- (void) checkIn : (int) index
{
    
    enterNameTF.text=[NSString stringWithFormat:@"%@ %@",[[self.tableDataArray objectAtIndex:index] valueForKey:@"first_name"], [[self.tableDataArray objectAtIndex:index] valueForKey:@"last_name"]];
    
    
    checkInDateTF.text = [NSString stringWithFormat:@"%@", [[self.tableDataArray objectAtIndex:index] valueForKey:@"check_in"] ];
    
    
    
    checkOutDateTF.text =[[self.tableDataArray objectAtIndex:index] valueForKey:@"check_out"];
    
    
    enterRoomTF.text = [[self.tableDataArray objectAtIndex:index] valueForKey:@"room_number"];
    
    
    
    
    checkInTimeTF.text =[[self.tableDataArray objectAtIndex:index] valueForKey:@"check_in_time"];
    CheckOutTimeTF.text =[[self.tableDataArray objectAtIndex:index] valueForKey:@"check_out_time"];
    
    
    
    selectedUserIdString=[[self.tableDataArray objectAtIndex:index] valueForKey:@"id"];
    
    if ([[[self.tableDataArray objectAtIndex:index] valueForKey:@"check_in_status"] isEqualToString:@"0"]) {
        checkInStatusLbl.text = @"NO";
    }
    else
        checkInStatusLbl.text = @"YES";
    
    [guestIV setImage:[UIImage imageNamed:[[self.tableDataArray objectAtIndex:index] valueForKey:@"image"]]];
    
    if ([[[self.tableDataArray objectAtIndex:index] valueForKey:@"pool"] isEqualToString:@"0"]) {
        meetingSwtich.on = NO;
    }
    else
        poolSwtich.on = YES;
    
    if ([[[self.tableDataArray objectAtIndex:index] valueForKey:@"meeting_room"]isEqualToString:@"0"]) {
        meetingSwtich.on = NO;
    }
    else
        meetingSwtich.on = YES;
    
    if ([[[self.tableDataArray objectAtIndex:index] valueForKey:@"elevator"] isEqualToString:@"0"]) {
        elevatorSwitch.on = NO;
    }
    else
        elevatorSwitch.on = YES;
    
    
    sendKeyBtn.tag = index;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UISwitch Method
- (IBAction)valueChanged:(BMXSwitch *)sender
{
    
}
-(void)initSwitch
{
    //init meeting room access
    [meetingSwtich setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [meetingSwtich setMaskImage: [UIImage imageNamed: @"mask1"]];
    [meetingSwtich setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [meetingSwtich setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [meetingSwtich setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    [meetingSwtich setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [meetingSwtich setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
    //init elevator access
    [elevatorSwitch setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [elevatorSwitch setMaskImage: [UIImage imageNamed: @"mask1"]];
    [elevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [elevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [elevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    [elevatorSwitch setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [elevatorSwitch setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
    //init pool access
    [poolSwtich setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [poolSwtich setMaskImage: [UIImage imageNamed: @"mask1"]];
    [poolSwtich setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [poolSwtich setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [poolSwtich setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    [poolSwtich setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [poolSwtich setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
}
-(void)initAgSwitch
{
    //init meeting room access
    [agMeetingSwtich setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [agMeetingSwtich setMaskImage: [UIImage imageNamed: @"mask1"]];
    [agMeetingSwtich setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [agMeetingSwtich setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [agMeetingSwtich setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    [agMeetingSwtich setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [agMeetingSwtich setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
    
    //init elevator access
    [agElevatorSwitch setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [agElevatorSwitch setMaskImage: [UIImage imageNamed: @"mask1"]];
    
    [agElevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [agElevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [agElevatorSwitch setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    
    
    
    [agElevatorSwitch setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [agElevatorSwitch setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
    
    //init pool access
    [agPoolSwtich setCanvasImage: [UIImage imageNamed: @"canvas1"]];
    [agPoolSwtich setMaskImage: [UIImage imageNamed: @"mask1"]];
    
    [agPoolSwtich setKnobImage: [UIImage imageNamed: @"knob-normal1"] forState: UIControlStateNormal];
    [agPoolSwtich setKnobImage: [UIImage imageNamed: @"knob-high1"] forState: UIControlStateHighlighted];
    [agPoolSwtich setKnobImage: [UIImage imageNamed: @"knob-disabled1"] forState: UIControlStateDisabled];
    
    
    
    [agPoolSwtich setContentImage: [UIImage imageNamed: @"content-normal1.png"] forState: UIControlStateNormal];
    [agPoolSwtich setContentImage: [UIImage imageNamed: @"content-disabled1"] forState: UIControlStateDisabled];
    
}



#pragma mark - Logout view  Method
- (IBAction)lockBtnTapped:(id)sender
{
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"OpenHotel Alert "
                                                      message:@"Are you sure, you want to log out?"
                                                     delegate:self
                                            cancelButtonTitle:@"Cancel"
                                            otherButtonTitles:@"Log out", nil];
    [message show];
    
    
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:@"Log out"])
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
@end
