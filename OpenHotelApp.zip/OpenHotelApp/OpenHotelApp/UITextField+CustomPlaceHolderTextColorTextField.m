//
//  UITextField+CustomPlaceHolderTextColorTextField.m
//  OpenHotelApp
//
//  Created by DebutMac3 on 11/07/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import "UITextField+CustomPlaceHolderTextColorTextField.h"

@implementation UITextField (CustomPlaceHolderTextColorTextField)
-(UITextField*)setPlaceHolderColor:(UIColor*)color
{
    
   // UITextField *textField;
     [self setValue:[UIColor redColor] forKeyPath:@"_placeholderLabel.textColor"];
     return self;
    
}

- (void)drawPlaceholderInRect:(CGRect)rect
{
    UIColor *colour = [UIColor grayColor];
    if ([self.placeholder respondsToSelector:@selector(drawInRect:withAttributes:)])
    { // iOS7 and later
        NSDictionary *attributes = @{NSForegroundColorAttributeName: colour, NSFontAttributeName: self.font}; CGRect boundingRect = [self.placeholder boundingRectWithSize:rect.size options:0 attributes:attributes context:nil]; [self.placeholder drawAtPoint:CGPointMake(0, (rect.size.height/2)-boundingRect.size.height/2) withAttributes:attributes]; }
        else { // iOS 6
            
            NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
            style.lineBreakMode = NSLineBreakByTruncatingTail;
         //   style.alignment = self.placeHolderTextAlignment;

             NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:style,NSParagraphStyleAttributeName, self.font, NSFontAttributeName, colour, NSForegroundColorAttributeName, nil];
            [self.placeholder drawInRect:rect withAttributes:attr];
            
         //   [self.placeholder drawInRect:rect withFont:self.font lineBreakMode:NSLineBreakByTruncatingTail alignment:self.textAlignment];
    }
    }

-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

@end
