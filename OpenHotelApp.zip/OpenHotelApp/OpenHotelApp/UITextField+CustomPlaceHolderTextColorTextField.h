//
//  UITextField+CustomPlaceHolderTextColorTextField.h
//  OpenHotelApp
//
//  Created by DebutMac3 on 11/07/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (CustomPlaceHolderTextColorTextField)
-(UITextField*)setPlaceHolderColor:(UIColor*)color;
- (void)drawPlaceholderInRect:(CGRect)rect;
-(BOOL) NSStringIsValidEmail:(NSString *)checkString;
@end
