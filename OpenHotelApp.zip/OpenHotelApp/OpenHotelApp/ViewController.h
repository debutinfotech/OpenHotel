//
//  ViewController.h
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UIProgressView *splashProgressView;
    
    IBOutlet UIButton *custoCameraBtn;
}

- (IBAction)customCameraBtnTapped:(id)sender;

@end
