

#import <Foundation/Foundation.h>

@interface Helper : NSObject

+(bool)isConnectedToInternet;

@end
