//
//  LoginVC.m
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import "LoginVC.h"
#import "Helper.h"
#import "LandingVC.h"


@interface LoginVC ()
@end

@implementation LoginVC


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    if (self)
    {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    lastEmpPinChar=@"";
    
MMProgressHUDDemoAnimationTypeBalloon:[MMProgressHUD setPresentationStyle:MMProgressHUDPresentationStyleExpand];
    
    oneNumericButton.layer.cornerRadius=35;
    oneNumericButton.clipsToBounds=YES;
    
    twoNumericButton.layer.cornerRadius=35;
    twoNumericButton.clipsToBounds=YES;
    
    threeNumericButton.layer.cornerRadius=35;
    threeNumericButton.clipsToBounds=YES;
    
    fourNumericButton.layer.cornerRadius=35;
    fourNumericButton.clipsToBounds=YES;
    
    fiveNumericButton.layer.cornerRadius=35;
    fiveNumericButton.clipsToBounds=YES;
    
    
    sixNumericButton.layer.cornerRadius=35;
    sixNumericButton.clipsToBounds=YES;
    
    sevenNumericButton.layer.cornerRadius=35;
    sevenNumericButton.clipsToBounds=YES;
    
    eightNumericButton.layer.cornerRadius=35;
    eightNumericButton.clipsToBounds=YES;
    
    nineNumericButton.layer.cornerRadius=35;
    nineNumericButton.clipsToBounds=YES;
    
    zeroNumericButton.layer.cornerRadius=35;
    zeroNumericButton.clipsToBounds=YES;
    
    enterButton.layer.cornerRadius=35;
    enterButton.clipsToBounds=YES;
    
    backSpaceButton.layer.cornerRadius=35;
    backSpaceButton.clipsToBounds=YES;
    
    
    empPinLabel.layer.borderColor = [[UIColor blackColor]CGColor];
    empPinLabel.layer.borderWidth = 1.5;
    
    
    [inputImageView setImage:[UIImage imageNamed:@"input_field.png"]];
    
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    //login button corner radius
    self.loginBtn.layer.cornerRadius = 5.0f;
    _usernameTF.layer.cornerRadius = 5.0f;
    _passwordTF.layer.cornerRadius = 5.0f;
    _forgotBtn.layer.cornerRadius = 5.0f;
    
    //code for the making textfiled text appearence after 10 points from left
    self.usernameTF.leftViewMode = UITextFieldViewModeAlways;
    UIView* leftView1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 10)];
    self.usernameTF.leftView = leftView1;
    
    //code for the making textfiled text appearence after 10 points from left
    self.passwordTF.leftViewMode = UITextFieldViewModeAlways;
    UIView* leftView2 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 10)];
    self.passwordTF.leftView = leftView2;
    
    
    
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    if ([def valueForKey:@"username"]) {
        self.usernameTF.text = [def valueForKey:@"username"];
        self.passwordTF.text = [def valueForKey:@"password"];
    }
    
    empPinLabel.text=@"";
    empPinString=@"";
    lastEmpPinChar=@"";
}


#pragma mark -Login Methods
-(void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    
    //  [self performSelector:@selector(loginAction) withObject:nil afterDelay:1.1];
}


- (IBAction)loginBtnTapped:(id)sender
{
    if ([Helper isConnectedToInternet])
    {
        //  self.popup = [[JKProgressHUD alloc] initWithFrame:CGRectMake(0, 0, 70, 70)];
        // [self.popup show];
        
        
        if (empPinString.length && empPinLabel.text.length)
        {
            [MMProgressHUD showWithTitle:@"Open Hotel" status:@"Loading..."];
            
            
            
            [self performSelector:@selector(loginAction) withObject:nil afterDelay:1.1];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter valid pin " delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
            empPinLabel.text=@"";
            empPinString=@"";
            lastEmpPinChar=@"";
            
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No internet" message:@"Please check your internet connection." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        empPinLabel.text=@"";
        empPinString=@"";
        lastEmpPinChar=@"";
        
    }
}


- (void) loginAction
{
    
    [MMProgressHUD show];
    NSMutableDictionary *mDict = [[NSMutableDictionary alloc] init];
    
    // [mDict setObject:@"username" forKey:@"username"];
    [mDict setObject:[NSString stringWithFormat:@"%@",empPinString] forKey:@"password"];
    [mDict setObject:@"enter_code" forKey:@"method"];
    
    WebService *obj = [[WebService alloc] init];
    
    NSLog(@"%@", mDict);
    
    NSMutableArray *respArray = [[NSMutableArray alloc] init];
    NSString *appendURL = @"user/login.php";
    
    respArray = [obj webServices:mDict :appendURL];
    
    NSLog(@"%@", respArray );
    
    if ([[respArray valueForKey:@"status"] isEqualToString:@"1"])
    {
        
        [self.view endEditing:YES];
        
        NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
        
        [def setObject:self.usernameTF.text forKey:@"username"];
        [def setObject:self.passwordTF.text forKey:@"password"];
        
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:[respArray valueForKey:@"resp"]];
        [def setObject:data forKey:@"userinfo"];
        
        
        [def synchronize];
        
        
        
        [MMProgressHUD dismissWithSuccess:@"Success!"];
        
        [self performSelector:@selector(goNext) withObject:nil afterDelay:1.6];
        
    }
    else if([[respArray valueForKey:@"status"] isEqualToString:@"0"]){
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Please enter valid pin." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        empPinLabel.text=@"";
        empPinString=@"";
        lastEmpPinChar=@"";
        
    }
    else{
        
        [MMProgressHUD dismiss];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Please try again" message:@"An error occured to load the data." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];
        empPinLabel.text=@"";
        empPinString=@"";
        lastEmpPinChar=@"";
        
    }
    
}

-(void)goNext {
    LandingVC *obj = [[LandingVC alloc] initWithNibName:@"LandingVC" bundle:nil];
    
    [self.navigationController pushViewController:obj animated:YES];
}




#pragma mark - Textfield Delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    if (textField == self.usernameTF)
    {
        [self.passwordTF becomeFirstResponder];
    }
    else if (textField == self.passwordTF)
    {
        [self.passwordTF resignFirstResponder];
    }
    
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Numberbutton Pressed Methods Delegate

-(IBAction)oneNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"1";
    [self fillEmpPinTextField:lastEmpPinChar];
    
}
-(IBAction)twoNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"2";
    [self fillEmpPinTextField:lastEmpPinChar];
}
-(IBAction)threeNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"3";
    [self fillEmpPinTextField:lastEmpPinChar];
}
-(IBAction)fourNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"4";
    [self fillEmpPinTextField:lastEmpPinChar];
}
-(IBAction)fiveNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"5";
    [self fillEmpPinTextField:lastEmpPinChar];
    
}
-(IBAction)sixNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"6";
    [self fillEmpPinTextField:lastEmpPinChar];
}
-(IBAction)sevenNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"7";
    [self fillEmpPinTextField:lastEmpPinChar];
    
}
-(IBAction)eightNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"8";
    [self fillEmpPinTextField:lastEmpPinChar];
    
}
-(IBAction)nineNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"9";
    [self fillEmpPinTextField:lastEmpPinChar];
    
}
-(IBAction)zeroNumericButtonTapped:(id)sender
{
    lastEmpPinChar=@"0";
    [self fillEmpPinTextField:lastEmpPinChar];
    
    
}
-(void)fillEmpPinTextField:(NSString*)lastEenterChar
{
    if (empPinString==nil || [empPinString isEqualToString:(id)[NSNull null]])
    {
        empPinString=[NSString stringWithFormat:@"%@",lastEenterChar];
    }
    else
    {
        empPinString=[NSString stringWithFormat:@"%@%@",empPinString,lastEenterChar];
    }
    
    if (empPinLabel.text==nil || [empPinLabel.text isEqualToString:(id)[NSNull null]])
    {
        empPinLabel.text=[NSString stringWithFormat:@"*"];
    }
    else
    {
        empPinLabel.text=[NSString stringWithFormat:@"%@*",empPinLabel.text];
    }
    
    // empPinLabel.text=empPinString;
    // empPinLabel.text=[NSString stringWithFormat:@""];
    
    
}
-(IBAction)backSpaceButtonTapped:(id)sender
{
    if (empPinLabel.text.length)
    {
        empPinLabel.text=[empPinLabel.text substringToIndex:empPinLabel.text.length-1];
        
        if (empPinString.length)
        {
            empPinString=[empPinString substringToIndex:empPinString.length-1];
            
            if (empPinString.length)
            {
                lastEmpPinChar=[empPinString substringToIndex:empPinString.length-1];
            }
            
        }
        
        
    }
    
}
-(IBAction)enterButtonTapped:(id)sender
{
    if ([Helper isConnectedToInternet])
    {
        //  self.popup = [[JKProgressHUD alloc] initWithFrame:CGRectMake(0, 0, 70, 70)];
        // [self.popup show];
        
        
        if (empPinString.length && empPinLabel.text.length)
        {
            [MMProgressHUD showWithTitle:@"Open Hotel" status:@"Loading..."];
            
            
            
            [self performSelector:@selector(loginAction) withObject:nil afterDelay:1.1];
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Error" message:@"Please enter valid pin " delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
            [alert show];
        }
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No internet" message:@"Please check your internet connection." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
    
    
    // [self loginAction];
}
@end
