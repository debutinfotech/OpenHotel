//
//  LoginVC.h
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginVC : UIViewController <UITextFieldDelegate, UIAlertViewDelegate>
{
    IBOutlet UILabel *empPinLabel;
    
    NSString *empPinString,*lastEmpPinChar;
    
    //Number Buttons
    IBOutlet UIButton *oneNumericButton,*twoNumericButton,*threeNumericButton,*fourNumericButton,*fiveNumericButton,*sixNumericButton,*sevenNumericButton,*eightNumericButton,*nineNumericButton,*zeroNumericButton,*backSpaceButton,*enterButton;
    
    IBOutlet UIImageView *inputImageView;
    
    
}
//@property (strong, nonatomic) IBOutlet UITextField *employeePinTF;
@property (strong, nonatomic) IBOutlet UITextField *usernameTF;
@property (strong, nonatomic) IBOutlet UITextField *passwordTF;
@property (strong, nonatomic) IBOutlet UIButton *loginBtn, *forgotBtn;

- (IBAction)loginBtnTapped:(id)sender;
-(IBAction)forgotPasswordBtnTapped:(id)sender;

//Number Buttons methods

-(IBAction)oneNumericButtonTapped:(id)sender;
-(IBAction)twoNumericButtonTapped:(id)sender;
-(IBAction)threeNumericButtonTapped:(id)sender;
-(IBAction)fourNumericButtonTapped:(id)sender;
-(IBAction)fiveNumericButtonTapped:(id)sender;
-(IBAction)sixNumericButtonTapped:(id)sender;
-(IBAction)sevenNumericButtonTapped:(id)sender;
-(IBAction)eightNumericButtonTapped:(id)sender;
-(IBAction)nineNumericButtonTapped:(id)sender;
-(IBAction)zeroNumericButtonTapped:(id)sender;
-(IBAction)backSpaceButtonTapped:(id)sender;
-(IBAction)enterButtonTapped:(id)sender;

@end
