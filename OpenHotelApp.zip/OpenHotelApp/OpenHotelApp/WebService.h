//
//  WebService.h
//  Barter
//
//  Created by Debut Infotech on 13/12/13.
//  Copyright (c) 2013 Debut Infotech. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WebService : NSObject

- (NSMutableArray *) webServices :(NSMutableDictionary *)  webDict :(NSString *) addUrl;                 //Hitting Web Services Method

@end
