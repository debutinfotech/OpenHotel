//
//  CustomCell.m
//  OpenHotelApp
//
//  Created by Debut Infotech Pvt Ltd. on 28/05/14.
//  Copyright (c) 2014 Debut Infotech Pvt. Ltd. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell
@synthesize delegate;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(IBAction)checkInButtonPressed:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(checkInButtonDelegateMethodPressed:)]) {
        [self.delegate checkInButtonDelegateMethodPressed:self];
    }
}
@end
